<?php
$config = [
    # find music file, must end with /
    'dir'    => '/Users/jea/Music/download/',
    # cache file dir when music delete or create ,run update.php to update
    'cacheFile' => './tmp/cache.json',
];
